﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicObjects
{
    public abstract class MusicGroup
    {
        public abstract void Play();
    }
}